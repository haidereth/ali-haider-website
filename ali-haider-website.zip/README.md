# Ali Haider — Connect PR Website

A single self-contained static site. All CSS, JavaScript, and photographs
are embedded directly inside `index.html` (fonts load from Google Fonts).
No build step, package manager, or dependencies are required.

## Deploy to GitHub + Cloudflare Pages

1. Create a new GitHub repository and add this `index.html` file to the
   repository root (commit it as-is).
2. In Cloudflare Pages, create a new project and connect it to that
   GitHub repository.
3. Build settings:
   - Framework preset: **None**
   - Build command: *(leave empty)*
   - Build output directory: `/`
4. Deploy. Cloudflare will serve `index.html` directly — no other
   configuration is needed.

## Local preview

Just open `index.html` in a browser, or serve the folder with any
static file server, e.g.:

```
npx serve .
```
